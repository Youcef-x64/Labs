-- INSERT INTO role (name)
-- VALUES
--     ('Admin'),
--     ('Dentist'),
--     ('Patient');

-- Generate fake data for the user table
CREATE TABLE user (
                      id INT AUTO_INCREMENT PRIMARY KEY,
                      email VARCHAR(255) NOT NULL,
                      first_name VARCHAR(255) NOT NULL,
                      last_name VARCHAR(255) NOT NULL,
                      phone VARCHAR(20) NOT NULL
);


INSERT INTO user (email, first_name, last_name, phone)
VALUES
    ('admin@example.com', 'Admin', 'User', '123-456-7890'),
    ('dentist1@example.com', 'John', 'Doe', '987-654-3210'),
    ('dentist2@example.com', 'Jane', 'Smith', '456-789-0123'),
    ('patient1@example.com', 'Alice', 'Johnson', '789-012-3456'),
    ('patient2@example.com', 'Bob', 'Williams', '012-345-6789'),
    ('patient3@example.com', 'Carol', 'Brown', '234-567-8901');

-- Generate fake data for the speciality table
-- INSERT INTO speciality (name)
-- VALUES
--     ('Orthodontist'),
--     ('Endodontist'),
--     ('Pedodontist');
--
-- -- Generate fake data for the dentist table
-- INSERT INTO dentist (id, speciality_id)
-- VALUES
--     (2, 2),
--     (3, 3);
--
-- -- Generate fake data for the patient table
-- INSERT INTO patient (id, dob)
-- VALUES
--     (4, '1990-01-01'),
--     (5, '1985-05-15'),
--     (6, '1978-09-20');
--
-- -- Generate fake data for the address table
-- INSERT INTO address (city, state, street)
-- VALUES
--     ('Fairfield', 'IA', '1000 N 4th ST'),
--     ('New York', 'NY', '123 Main St'),
--     ('Los Angeles', 'CA', '456 Elm St');
--
-- -- Generate fake data for the surgery table
-- INSERT INTO surgery (name, address_id)
-- VALUES
--     ('Surgery 1', 1),
--     ('Surgery 2', 2),
--     ('Surgery 3', 3);
--
-- -- Generate fake data for the appointment table
-- INSERT INTO appointment (date_time, dentist_id, patient_id, surgery_id)
-- VALUES
--     ('2024-04-12 10:30:00', 2, 3, 2),
--     ('2024-04-13 11:15:00', 3, 4, 3);
--
-- -- Generate fake data for the user_role table
-- INSERT INTO user_role (role_id, user_id)
-- VALUES
--     (1, 1),
--     (2, 2),
--     (2, 3),
--     (3, 4),
--     (3, 5),
--     (3, 6);