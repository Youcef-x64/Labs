package com.example.demo.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Dentist {

    @ManyToOne
    @JoinColumn(name = "speciality_id")
    private Speciality speciality;
    @OneToMany(mappedBy = "dentist")
    private List<Appointment> appointment;

}
